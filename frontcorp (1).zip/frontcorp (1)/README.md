# Frontier Failure Corpus v1.0

This repository contains a curated dataset of cross-domain prompt failures that cause JSON pipeline collapse in frontier LLMs.  
The data is released under Apache 2.0.

## Quick-start

```bash
git clone https://github.com/[YOUR_HANDLE]/frontier-failure-corpus.git
cd frontier-failure-corpus
pip install -r requirements.txt   # pandas, matplotlib, seaborn
jupyter notebook notebooks/reproduce_plots.ipynb